(function () {
  const STORAGE_KEY = "mirror_me_accounts_v2";
  const DEEPSEEK_KEY = "mirror_me_deepseek_key";
  const ONLINE_AI_ENABLED = "mirror_me_online_ai_enabled";
  const $ = (selector) => document.querySelector(selector);

  const chatForm = $("#chatForm");
  const chatText = $("#chatText");
  const chatWindow = $("#chatWindow");
  const currentAccountSelect = $("#currentAccountSelect");
  const panelTitle = document.querySelector(".chat-panel .panel-title");

  if (!chatForm || !chatText || !chatWindow || !panelTitle) return;

  localStorage.setItem(ONLINE_AI_ENABLED, localStorage.getItem(ONLINE_AI_ENABLED) || "true");

  const controls = document.createElement("div");
  controls.className = "ai-provider-bar";
  controls.innerHTML = `
    <span id="aiProviderStatus">在线 AI：自动</span>
    <button type="button" id="toggleOnlineAi">切换</button>
    <button type="button" id="setDeepSeekKey">DeepSeek Key</button>
  `;
  panelTitle.insertAdjacentElement("afterend", controls);

  const style = document.createElement("style");
  style.textContent = `
    .ai-provider-bar {
      display: flex;
      align-items: center;
      gap: 8px;
      flex-wrap: wrap;
      margin: -4px 0 12px 60px;
      color: #667085;
      font-size: 12px;
      font-weight: 800;
    }
    .ai-provider-bar button {
      min-height: 28px;
      padding: 4px 9px;
      border: 1px solid #d9e3e6;
      border-radius: 999px;
      background: #fff;
      color: #09665d;
      cursor: pointer;
      font: inherit;
    }
    @media (max-width: 700px) {
      .ai-provider-bar { margin-left: 0; }
    }
  `;
  document.head.appendChild(style);

  function loadState() {
    try {
      return JSON.parse(localStorage.getItem(STORAGE_KEY)) || null;
    } catch {
      return null;
    }
  }

  function saveState(state) {
    if (state) localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  }

  function currentAccount(state) {
    if (!state?.accounts?.length) return null;
    const id = currentAccountSelect?.value || state.currentId;
    return state.accounts.find((account) => account.id === id) || state.accounts[0];
  }

  function appendMessage(text, type) {
    const message = document.createElement("div");
    message.className = `message ${type}`;
    message.textContent = text;
    chatWindow.appendChild(message);
    chatWindow.scrollTop = chatWindow.scrollHeight;
    return message;
  }

  function saveMessage(type, text) {
    const state = loadState();
    const account = currentAccount(state);
    if (!account) return;
    if (!Array.isArray(account.chatMessages)) account.chatMessages = [];
    if (!Array.isArray(account.chatHistory)) account.chatHistory = [];
    account.chatMessages.push({ type, text });
    if (type === "user") account.chatHistory.push(text);
    saveState(state);
    window.dispatchEvent(new Event("mirrorChatHistoryUpdated"));
  }

  function setStatus(text) {
    const status = $("#aiProviderStatus");
    if (status) status.textContent = text;
  }

  function cleanReply(text) {
    return String(text || "")
      .replace(/^小Me[:：]\s*/i, "")
      .replace(/\n{3,}/g, "\n\n")
      .trim()
      .slice(0, 240);
  }

  function localFriendReply(text) {
    if (/压力|焦虑|累|难过|烦|崩溃/.test(text)) {
      return "我在。先不用急着把自己整理得很清楚，你可以从最让你累的那一小块开始说。";
    }
    if (/朋友|关系|社交|同学|喜欢的人|聊天/.test(text)) {
      return "关系里的细节真的会牵动人。你愿意讲讲，当时最让你在意的是对方的哪句话或哪个反应吗？";
    }
    if (/未来|计划|目标|职业|考研|工作/.test(text)) {
      return "未来这件事很容易一边让人期待，一边让人紧张。你现在更想先聊方向，还是聊最近的一步？";
    }
    if (/心理|MBTI|人格|大五|自我/.test(text)) {
      return "这个话题我很愿意陪你慢慢聊。你最近是因为课程、生活里的某件事，还是和别人相处时突然开始好奇自己的？";
    }
    return "嗯，我在听。你可以继续说一点，我想知道这件事对你来说真正重要的地方是什么。";
  }

  function buildMessages(userText) {
    const state = loadState();
    const account = currentAccount(state);
    const history = (account?.chatMessages || []).slice(-8).map((message) => ({
      role: message.type === "user" ? "user" : "assistant",
      content: message.text
    }));
    return [
      {
        role: "system",
        content: "你是 Mirror ME 的小Me，一个自然、温柔、像朋友一样的中文聊天对象。你不做诊断，不主动打分，不刻意收集人格数据，不频繁提雷达图或人格维度。你要像真实朋友一样回应用户的生活、学习、兴趣、情绪和人际关系，语气轻松、具体、有共情。回复控制在80字以内，优先接住对方的话，再自然追问一个开放问题。"
      },
      ...history,
      { role: "user", content: userText }
    ];
  }

  async function withTimeout(promise, ms = 14000) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), ms);
    try {
      return await promise(controller.signal);
    } finally {
      clearTimeout(timer);
    }
  }

  async function retryProvider(task, attempts = 1) {
    let lastError = null;
    for (let index = 0; index < attempts; index += 1) {
      try {
        const reply = await task();
        if (reply) return cleanReply(reply);
      } catch (error) {
        lastError = error;
        await new Promise((resolve) => setTimeout(resolve, 500 + index * 800));
      }
    }
    throw lastError || new Error("empty reply");
  }

  async function callDeepSeek(userText) {
    const key = localStorage.getItem(DEEPSEEK_KEY);
    if (!key) return null;
    return withTimeout(async (signal) => {
      const response = await fetch("https://api.deepseek.com/chat/completions", {
        method: "POST",
        signal,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${key}`
        },
        body: JSON.stringify({
          model: "deepseek-chat",
          messages: buildMessages(userText),
          temperature: 0.8,
          max_tokens: 180
        })
      });
      if (!response.ok) throw new Error(`DeepSeek ${response.status}`);
      const data = await response.json();
      return data?.choices?.[0]?.message?.content || null;
    }, 12000);
  }

  async function callPublicOpenAi(userText) {
    return withTimeout(async (signal) => {
      const response = await fetch("https://text.pollinations.ai/openai", {
        method: "POST",
        signal,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "openai",
          messages: buildMessages(userText),
          temperature: 0.8,
          max_tokens: 180
        })
      });
      if (!response.ok) throw new Error(`Public AI ${response.status}`);
      const data = await response.json();
      return data?.choices?.[0]?.message?.content || null;
    }, 9000);
  }

  function buildTextPrompt(userText) {
    const state = loadState();
    const account = currentAccount(state);
    const history = (account?.chatMessages || [])
      .slice(-6)
      .map((message) => `${message.type === "user" ? "用户" : "小Me"}：${message.text}`)
      .join("\n");
    return [
      "你是 Mirror ME 的小Me，一个自然、温柔、像朋友一样的中文聊天对象。",
      "不要诊断，不要主动打分，不要刻意收集人格数据，不要提雷达图。",
      "回复80字以内，先接住对方的话，再自然追问一个开放问题。",
      history ? `最近对话：\n${history}` : "",
      `用户刚刚说：${userText}`,
      "小Me回复："
    ].filter(Boolean).join("\n");
  }

  async function callPublicTextAi(userText) {
    return withTimeout(async (signal) => {
      const prompt = encodeURIComponent(buildTextPrompt(userText));
      const response = await fetch(`https://text.pollinations.ai/${prompt}?model=openai&temperature=0.8&private=true`, {
        method: "GET",
        signal,
        cache: "no-store"
      });
      if (!response.ok) throw new Error(`Public text AI ${response.status}`);
      return await response.text();
    }, 9000);
  }

  async function firstPublicReply(userText) {
    const providers = [
      retryProvider(() => callPublicOpenAi(userText)),
      retryProvider(() => callPublicTextAi(userText))
    ];
    try {
      return await Promise.any(providers);
    } catch {
      return null;
    }
  }

  function localReplyAfter(userText, ms = 8500) {
    return new Promise((resolve) => {
      setTimeout(() => resolve({ reply: localFriendReply(userText), online: false }), ms);
    });
  }

  async function getAiReply(userText) {
    if (localStorage.getItem(ONLINE_AI_ENABLED) !== "true") {
      setStatus("在线 AI：关闭");
      return localFriendReply(userText);
    }
    setStatus("在线 AI：连接中");
    if (localStorage.getItem(DEEPSEEK_KEY)) {
      try {
        const deepSeekReply = await retryProvider(() => callDeepSeek(userText));
        if (deepSeekReply) {
          setStatus("在线 AI：DeepSeek");
          return deepSeekReply;
        }
      } catch {
        setStatus("DeepSeek 未连通，尝试备用线路");
      }
    } else {
      setStatus("备用线路连接中");
    }
    try {
      const result = await Promise.race([
        firstPublicReply(userText).then((reply) => reply ? { reply, online: true } : null),
        localReplyAfter(userText)
      ]);
      if (result?.reply && result.online) {
        setStatus("在线 AI：备用模型");
        return result.reply;
      }
      if (result?.reply) {
        setStatus("备用线路较忙，已快速切换本地回复");
        return result.reply;
      }
    } catch {
      // Promise.any errors are normalized in firstPublicReply; this is a final guard.
    }
    setStatus("网络波动，已切换本地好友回复");
    return localFriendReply(userText);
  }

  chatForm.addEventListener("submit", async (event) => {
    event.preventDefault();
    event.stopImmediatePropagation();
    const text = chatText.value.trim();
    if (!text) return;
    appendMessage(text, "user");
    saveMessage("user", text);
    chatText.value = "";
    const thinking = appendMessage("小Me正在想怎么回你...", "ai");
    const reply = await getAiReply(text);
    thinking.textContent = reply;
    saveMessage("ai", reply);
  }, true);

  $("#toggleOnlineAi")?.addEventListener("click", () => {
    const enabled = localStorage.getItem(ONLINE_AI_ENABLED) === "true";
    localStorage.setItem(ONLINE_AI_ENABLED, enabled ? "false" : "true");
    setStatus(enabled ? "在线 AI：关闭" : "在线 AI：自动");
  });

  $("#setDeepSeekKey")?.addEventListener("click", () => {
    const current = localStorage.getItem(DEEPSEEK_KEY) || "";
    const key = prompt("请输入 DeepSeek API Key。它只会保存在你当前浏览器的 localStorage 中；如果留空会删除。", current);
    if (key === null) return;
    if (key.trim()) {
      localStorage.setItem(DEEPSEEK_KEY, key.trim());
      setStatus("在线 AI：DeepSeek 已配置");
    } else {
      localStorage.removeItem(DEEPSEEK_KEY);
      setStatus("在线 AI：自动");
    }
  });

  setStatus(localStorage.getItem(ONLINE_AI_ENABLED) === "true" ? "在线 AI：自动" : "在线 AI：关闭");
})();
